<!DOCTYPE html>
<html>
<head>
    <title>Affichage des élèves</title>
    <!-- <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/affiche.css') }}"> -->
    <!-- <link href="{{ asset('assets/css/affiche.css') }}" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="assets/css/affiche.css">

</head>
<body>
    <h1>Liste des eleves</h1>
    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Date de Naissance</th>
                <th>Date d'Inscription</th>
                <th>Classe</th>
            </tr>
        </thead>
        <tbody>
            @foreach($eleves as $eleve)
                <tr>
                    <td>{{ $eleve->nom }}</td>
                    <td>{{ $eleve->dtn }}</td>
                    <td>{{ $eleve->date_inscription }}</td>
                    <td>{{ $eleve->classe }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
