create database gestion_eleve;

CREATE TABLE Description_eleve (
    idDE serial PRIMARY KEY,
    nom varchar(90),
    dtn date,
    date_inscription date,
    classe varchar(20)
);

insert into Description_eleve (nom, dtn, date_inscription, classe) values ('eleve1', '2000-11-03', '2023-11-03','terminal');

insert into Description_eleve (nom, dtn, date_inscription, classe) values ('eleve2', '2002-11-03', '2023-11-03','terminal');
