<!DOCTYPE html>
<html>
<head>
    <title>Affichage des élèves</title>
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/affiche.css')); ?>"> -->
    <!-- <link href="<?php echo e(asset('assets/css/affiche.css')); ?>" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="assets/css/affiche.css">

</head>
<body>
    <h1>Liste des eleves</h1>
    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Date de Naissance</th>
                <th>Date d'Inscription</th>
                <th>Classe</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($eleve->nom); ?></td>
                    <td><?php echo e($eleve->dtn); ?></td>
                    <td><?php echo e($eleve->date_inscription); ?></td>
                    <td><?php echo e($eleve->classe); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\Bruner Lee Rudy\Documents\Dossier C\ITU\L3\S6\Laravel\project\eleve-app\resources\views/Affichage.blade.php ENDPATH**/ ?>