<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\eleveModel;

class eleveController extends Controller
{
    public function selectEleve()
    {
        $eleves = eleveModel::all();
        return view('Affichage', compact('eleves'));
    }
}
